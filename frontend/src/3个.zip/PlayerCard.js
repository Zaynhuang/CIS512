import React from "react";
import "./PlayerCard.css"; // Make sure you have a corresponding CSS file
import playerIcon from "./image/title_image.png";
import {
  Radar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  ResponsiveContainer,
} from "recharts";

import defaultNcaaImage from "./playImageSample/Jason_Tatum.png"; // Default NCAA player image
import defaultNbaImage from "./playImageSample/victor-wembanyama.png"; // Default NBA player image

const PlayerCard = ({ player }) => {
  // if (!player) {
  //     // You could return null or some placeholder
  //     return <div>No player selected</div>;
  // }

  const defaultImage =
    player.league === "NCAA" ? defaultNcaaImage : defaultNbaImage;

  return (
    <div className="player-card">
      <div className="upper_part">
        <div className="playerCard-icon-container">
          {/* Assuming you have an SVG or PNG icon for the 'Future Superstar Predictor' */}
          <img
            src={playerIcon}
            alt="PlayerCard Icon"
            className="playerCard-icon"
          />
        </div>

        <div className="playerCard-image-container">
          {/*<img src={imagePath} alt={player.name} className="playerCard-image" />*/}
          <img
            src={player.pic_url || defaultImage}
            alt={player.name}
            className="playerCard-image"
          />
        </div>
      </div>

      {/* New rating badge */}
      <div className="player-rating-badge">{player.rating}</div>

      <div className="playerCard-info">
        <h2>{player.name}</h2>
        <div className="below_part_stats">
          <div className="playerCard-stats">
            <h2>
              {player.First_Name} {player.Last_Name}
            </h2>{" "}
            <div className="stat-item">Weight: {player.Team_Name}</div>
            <div className="stat-item">Number: {player.Avg_PTS}</div>
            <div className="stat-item">Points: {player.Avg_REB}</div>
            <div className="stat-item">Rebounds: {player.Avg_AST}</div>
            <div className="stat-item">Assists: {player.Avg_STL}</div>
            <div className="stat-item">Avg_BLK: {player.Avg_BLK}</div>
            <div className="stat-item">Avg_FG3_PCT: {player.Avg_FG3_PCT}</div>
            <div className="stat-item">Avg_FG_PCT: {player.Avg_FG_PCT}</div>
            <div className="stat-item">Avg_FT_PCT: {player.Avg_FT_PCT}</div>
            <div className="stat-item">Avg_OREB: {player.Avg_OREB}</div>
            <div className="stat-item">Avg_DREB: {player.Avg_DREB}</div>
            <div className="stat-item">Avg_TOV: {player.Avg_TOV}</div>
            <div className="stat-item">Avg_MIN: {player.Avg_MIN}</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PlayerCard;
