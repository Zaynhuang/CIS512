// StatisticsComparison.js
import React from 'react';
import {
    BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer
} from 'recharts';
import './StatisticsComparison.css'

const StatisticsComparison = ({ playerStats, averageStats }) => {
    // Transform the playerStats and averageStats into an array of data objects for the chart
    const data = Object.keys(averageStats).map(stat => ({
        name: stat,
        Player: playerStats[stat],
        Average: averageStats[stat],
    }));

    return (
        <ResponsiveContainer width="100%" height="100%">
            <BarChart
                data={data}
                layout="vertical"
                margin={{
                    top: 20, right: 30, left: 100, bottom: 5,
                }}
            >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" tick={{ fill: '#ffffff' }}/>
                <YAxis type="category" dataKey="name" tick={{ fill: '#ffffff' }} />
                <Tooltip />
                <Legend />
                <Bar dataKey="Player" fill="#aeaaff" />
                <Bar dataKey="Average" fill="#ef6eff" />
            </BarChart>
        </ResponsiveContainer>
    );
};

export default StatisticsComparison;
